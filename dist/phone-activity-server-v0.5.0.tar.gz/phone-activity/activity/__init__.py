"""Private phone activity dashboard."""
