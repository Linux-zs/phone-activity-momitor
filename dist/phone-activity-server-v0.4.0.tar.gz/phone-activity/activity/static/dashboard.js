const $ = id => document.getElementById(id);
const date = ms => ms == null ? "尚无记录" : new Intl.DateTimeFormat("zh-CN", {timeZone:"Asia/Shanghai",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(new Date(ms));
const duration = ms => `${Math.floor(ms/3600000)}时${Math.floor(ms%3600000/60000)}分`;
const labels = {unlock:"锁屏解除",lock:"进入锁屏",screen_on:"交互亮屏",screen_off:"退出交互亮屏",reset:"记录边界／设备重启"};
function cell(row, text) { const td=document.createElement("td");td.textContent=text;row.append(td); }
async function refresh(){
  try{
    const res=await fetch("/api/v1/dashboard",{cache:"no-store"});
    if(res.status===401){location.replace("/login");return;}
    if(!res.ok)throw new Error("读取失败");
    const data=await res.json(), s=data.snapshot, today=data.daily.at(-1);
    $("error").textContent="";
    $("last-unlock").textContent=date(data.last_unlock);
    const diagnostics={permission_denied:"采集权限未开启",user_locked:"重启后尚未解锁",history_gap:"历史记录可能缺失",clock_changed:"手机时间发生回拨",query_failed:"系统历史读取失败"};
    $("status").textContent=data.stale?"数据已过期，当前状态未知":!s?.permission?"采集权限未开启":diagnostics[s?.diagnostic]||"已收到近期数据 · 非实时";
    $("status").classList.toggle("stale",data.stale||!s?.permission||s?.diagnostic!=="ok");
    $("received").textContent=`服务器收到：${date(s?.received)}`;
    $("covered").textContent=`最近采集至：${date(s?.covered_until)}`;
    $("unlocks").textContent=today.unlocks;
    $("screen").textContent=duration(today.screen_ms);
    $("unlocked").textContent=duration(today.unlocked_ms);
    $("battery").textContent=s?.battery==null?"—":`${s.battery}%`;
    $("charging").textContent=s?.charging==null?"状态未知":s.charging?"正在充电":"未充电";
    $("quality").textContent=today.incomplete?"今日记录不完整或有未结束时段。时长仅累计可确认区间，未记录不等于没有使用。":"今日已采集时段连续；时长仅累计已结束的区间。";
    $("days").replaceChildren();
    [...data.daily].reverse().forEach(d=>{const row=document.createElement("tr");[d.date,d.unlocks,duration(d.screen_ms),duration(d.unlocked_ms),d.incomplete?"不完整":"连续"].forEach(v=>cell(row,v));$("days").append(row);});
    $("timeline").replaceChildren();
    data.timeline.forEach(e=>{const li=document.createElement("li"),t=document.createElement("time"),label=document.createElement("span");t.textContent=date(e.at);label.textContent=labels[e.kind]||e.kind;li.append(t,label);$("timeline").append(li);});
    if(!data.timeline.length){const li=document.createElement("li");li.textContent="等待手机首次同步";$("timeline").append(li);}
  }catch{ $("error").textContent="无法刷新，请检查网络；下方为上次读取结果。";$("status").textContent="刷新失败，当前状态未知";$("status").classList.add("stale"); }
}
refresh();setInterval(refresh,60000);
