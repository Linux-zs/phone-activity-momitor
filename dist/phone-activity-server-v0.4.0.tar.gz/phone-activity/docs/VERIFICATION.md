# 验证记录 · v0.4.0

日期：2026-09-19。构建环境：Windows、JDK 17、Android SDK 36。服务端在本地 Python 3.11.9 验证；不是 Rocky Linux 实机验证。

## 已完成

- Android `testDebugUnitTest lintDebug assembleDebug` 成功，5 项单元测试通过。覆盖 HTTPS 地址、稳定事件 ID、上海零点及回查窗口、确认 ID 匹配、HTTP 重试分类。
- Android Lint 无错误；仍有依赖升级、同步偏好写入、KTX 使用建议及旧图标未引用等警告。没有用全局 baseline 隐藏错误。
- APK `apksigner verify --verbose` 验证成功，v2 签名有效。保留原包名和本机 Debug 签名。
- Python 3.11.9：项目测试 10 项通过，验证上传／查看鉴权隔离、Cookie 属性、来源校验、登录限速、重复上传、历史时间、设备冲突、时间偏差、过期清理、跨午夜、缺失区间、权限拒绝、备份恢复。测试依赖有两条弃用警告，无失败。
- 依赖锁文件中的包均声明兼容 Python 3.11，实际安装了 CPython 3.11 对应依赖并运行测试。Python 3.13 也通过了初期 8 项测试。
- JavaScript 语法检查通过。
- Playwright 使用本地模拟数据完成真实浏览器登录、看板加载和退出登录；修复了 Referrer 策略导致表单 Origin 为 null 而被拒绝的问题。
- 桌面及 390×844 手机宽度截图已检查，手机页面横向内容宽度为 390，无整体横向溢出。模拟数据正确显示 8 次解锁、2 小时亮屏、68% 电量。
- 包采用源文件白名单，排除虚拟环境、数据库、密钥、缓存和本地预览脚本；Linux 源文件权限统一为 0644。

## 未验证／不作保证

- 没有连接 Android 手机或模拟器。未验证真实安装、UsageStats 在 HyperOS 上的事件完整性、SQLite 断电行为、升级迁移运行和后台调度。
- 单元测试覆盖上传确认决策，不替代手机离线／杀进程下的完整队列测试；请执行 `PHONE-TEST.md`。
- 未登录云服务器，未执行 Rocky Linux 的 systemd、SELinux、Nginx 或 ACME 实际部署。部署说明给出相应步骤，现场须运行 `nginx -t` 并检查服务日志。
- 不保证每 30 分钟准点同步，没有实测耗电比例，也不把未收到手机数据解释为人身异常。
- 浏览器测试为本机 HTTP 回环地址的合成数据；正式服务必须启用 HTTPS，Android 不提供跳过证书检查的选项。
