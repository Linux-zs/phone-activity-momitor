from datetime import datetime
import hashlib
import time
import subprocess
import sys

import pytest
from fastapi.testclient import TestClient

from activity.main import create_app
from activity.db import connect
from activity.security import hash_password, digest
from activity.stats import aggregate, ZONE, DAY

TOKEN = "test-upload-token-which-is-not-production"
PASSWORD = "test-viewer-password"


def eid(value):
    return hashlib.sha256(value.encode()).hexdigest()


def event(at, kind):
    return {"id": eid(f"{at}:{kind}"), "at": at, "kind": kind}


@pytest.fixture
def system(tmp_path):
    path = tmp_path / "test.db"
    app = create_app({"password_hash": hash_password(PASSWORD), "upload_hash": digest(TOKEN)}, path)
    with TestClient(app, base_url="https://testserver") as client:
        yield client, path


def login(client):
    return client.post("/login", data={"password": PASSWORD}, headers={"Origin": "https://testserver"}, follow_redirects=False)


def payload():
    now = int(time.time() * 1000)
    return {"device_id": "test-device", "captured_at": now, "covered_until": now,
            "battery": 75, "charging": False, "network": "wifi", "permission": True,
            "diagnostic": "ok", "events": [event(now - 60000, "unlock")],
            "coverage": [{"id": eid("coverage"), "start": now - 120000, "end": now}]}


def upload(client, data):
    return client.post("/api/v1/sync", json=data, headers={"Authorization": "Bearer " + TOKEN})


def test_auth_and_cookie_separation(system):
    client, _ = system
    assert client.get("/api/v1/dashboard").status_code == 401
    assert client.post("/api/v1/sync", json=payload()).status_code == 401
    assert client.post("/login", data={"password": PASSWORD}, headers={"Origin": "null"}).status_code == 403
    response = login(client)
    assert response.status_code == 303
    cookie = response.headers["set-cookie"]
    assert "Secure" in cookie and "HttpOnly" in cookie and "SameSite=strict" in cookie
    assert client.get("/").status_code == 200
    assert client.get("/api/v1/dashboard").headers["cache-control"] == "no-store, private"
    assert client.post("/api/v1/sync", json=payload()).status_code == 401
    assert client.post("/logout", headers={"Origin": "https://evil.example"}).status_code == 403
    assert client.post("/logout", follow_redirects=False).status_code == 303
    assert client.get("/api/v1/dashboard").status_code == 401


def test_idempotent_upload_and_historical_time(system):
    client, path = system
    p = payload()
    p["events"][0] = event(p["captured_at"] - DAY, "unlock")
    assert upload(client, p).status_code == 200
    assert upload(client, p).status_code == 200
    with connect(path) as db:
        assert db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 1
    login(client)
    data = client.get("/api/v1/dashboard").json()
    assert data["last_unlock"] == p["events"][0]["at"]
    assert data["snapshot"]["received"] >= p["captured_at"]
    assert not data["stale"]


def test_binding_conflict_and_clock_skew(system):
    client, _ = system
    p = payload()
    assert upload(client, p).status_code == 200
    p["device_id"] = "another-device"
    assert upload(client, p).status_code == 409
    p["device_id"] = "test-device"
    p["events"][0]["kind"] = "lock"
    assert upload(client, p).status_code == 409
    p["captured_at"] += DAY
    assert upload(client, p).status_code == 422


def test_expiry_and_stale(system):
    client, path = system
    p = payload()
    upload(client, p)
    with connect(path) as db:
        db.execute("UPDATE snapshots SET received=?", (p["captured_at"] - 3 * 3600000,))
        db.execute("INSERT INTO events VALUES (?,?,?)", (eid("old"), p["captured_at"] - 31 * DAY, "unlock"))
    login(client)
    data = client.get("/api/v1/dashboard").json()
    assert data["stale"]
    assert len(data["timeline"]) == 1


def test_login_rate_limit(system):
    client, _ = system
    for _ in range(10):
        assert client.post("/login", data={"password": "wrong"}).status_code == 401
    assert login(client).status_code == 429


def test_cross_midnight_and_notification_only():
    at = int(datetime(2026, 9, 19, 23, 59, tzinfo=ZONE).timestamp() * 1000)
    events = [event(at, "screen_on"), event(at + 10000, "unlock"), event(at + 120000, "screen_off"),
              event(at + 180000, "screen_on"), event(at + 190000, "screen_off")]
    result = aggregate(events, [(at, at + 200000)], at + 200000)
    a, b = result["daily"][-2:]
    assert a["screen_ms"] == 60000 and b["screen_ms"] == 70000
    assert a["unlocked_ms"] == 50000 and b["unlocked_ms"] == 60000
    assert a["unlocks"] == 1 and b["unlocks"] == 0


def test_missing_event_gap_and_reset_are_not_duration():
    now = int(time.time() * 1000)
    start = now - 3600000
    for events, ranges in [
        ([event(start, "screen_on")], [(start, now)]),
        ([event(start, "screen_on"), event(now, "screen_off")], [(start, start + 1000), (now - 1000, now)]),
        ([event(start, "screen_on"), event(start + 10, "unlock"), event(now, "reset")], [(start, now)]),
    ]:
        result = aggregate(events, ranges, now)
        assert sum(d["screen_ms"] for d in result["daily"]) == 0
        assert sum(d["unlocked_ms"] for d in result["daily"]) == 0
        assert result["daily"][-1]["incomplete"]


def test_event_page_without_coverage_does_not_inflate_totals(system):
    client, _ = system
    p = payload()
    p["events"] = [event(p["captured_at"] - 60000, "screen_on"), event(p["captured_at"] - 1000, "screen_off")]
    p["coverage"] = []
    p["covered_until"] = None
    assert upload(client, p).status_code == 200
    login(client)
    assert sum(d["screen_ms"] for d in client.get("/api/v1/dashboard").json()["daily"]) == 0


def test_backup_restore_cli(system, tmp_path):
    client, path = system
    upload(client, payload())
    backup = tmp_path / "backup.db"
    restored = tmp_path / "restored.db"
    subprocess.run([sys.executable, "-m", "activity.manage", "backup", "--db", str(path), "--output", str(backup)], check=True, capture_output=True)
    subprocess.run([sys.executable, "-m", "activity.manage", "restore", "--db", str(restored), "--input", str(backup)], check=True, capture_output=True)
    with connect(restored) as db:
        assert db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 1


def test_permission_denied_does_not_claim_coverage(system):
    client, _ = system
    p = payload()
    p.update(permission=False, diagnostic="permission_denied", covered_until=None, events=[], coverage=[])
    assert upload(client, p).status_code == 200
    login(client)
    data = client.get("/api/v1/dashboard").json()
    assert data["snapshot"]["permission"] == 0
    assert data["snapshot"]["covered_until"] is None
    assert data["daily"][-1]["incomplete"]
