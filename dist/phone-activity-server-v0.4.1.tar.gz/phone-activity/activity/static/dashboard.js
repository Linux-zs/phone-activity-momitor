'use strict';
const $ = id => document.getElementById(id);
const zone = 'Asia/Shanghai';
const dateKey = value => new Intl.DateTimeFormat('en-CA', {timeZone: zone, year:'numeric', month:'2-digit', day:'2-digit'}).format(value);
const formatTime = (value, seconds = false) => new Intl.DateTimeFormat('zh-CN', {timeZone:zone, hour:'2-digit', minute:'2-digit', ...(seconds ? {second:'2-digit'} : {}), hourCycle:'h23'}).format(value);
const stamp = value => value == null ? '尚无记录' : `${dateKey(value).slice(5).replace('-', '/')} ${formatTime(value)}`;
const kinds = {unlock:['解锁','UNLOCK'], lock:['锁屏','LOCK'], screen_on:['亮屏','SCREEN ON'], screen_off:['熄屏','SCREEN OFF'], reset:['采集边界重置','RESET']};
let data = null;
let selected = null;
let range = 7;
let expanded = false;
let inFlight = false;
let fetchedAt = 0;
let failed = false;

function duration(id, ms, available) {
  const target = $(id);
  target.replaceChildren();
  if (!available) { target.textContent = '—'; return; }
  const minutes = Math.floor(ms / 60000);
  if (ms > 0 && minutes === 0) { target.textContent = '<1'; const unit = document.createElement('span'); unit.className='unit'; unit.textContent='分'; target.append(unit); return; }
  const pieces = minutes >= 60 ? [[Math.floor(minutes/60),'时'], [minutes%60,'分']] : [[minutes,'分']];
  pieces.forEach(([number, label]) => { target.append(document.createTextNode(String(number))); const unit=document.createElement('span'); unit.className='unit'; unit.textContent=label; target.append(unit); });
}

function renderStatus() {
  if (!data) return;
  const s = data.snapshot;
  const now = data.server_time + Math.max(0, Date.now() - fetchedAt);
  const stale = !s || now - s.received > 7200000;
  let label = '最近已收到上报';
  let note = '约每 30 分钟尝试同步，后台限制可能使上报延迟。';
  if (!s) { label='尚未收到上报'; note='手机完成首次同步后，这里会留下第一笔记录。'; }
  else if (stale) { label='数据已过期'; note='超过两小时未收到上报，当前状态未知。'; }
  else if (!s.permission || s.diagnostic === 'permission_denied') { label='采集权限未开启'; note='手机未获得使用情况访问权限，活动记录可能缺失。'; }
  else if (s.diagnostic !== 'ok') {
    label='采集有缺口';
    note=({history_gap:'部分系统历史已不可用，记录可能不完整。', user_locked:'等待手机首次解锁后继续采集。', clock_changed:'手机时间发生变化，异常时间段未计入统计。', query_failed:'最近一次查询失败，等待手机重试。'})[s.diagnostic] || '记录可能不完整，请查看手机采集状态。';
  }
  if (failed) { label='刷新失败'; note='无法获取最新数据；页面保留上次成功读取的记录。'; }
  $('status').textContent=label;
  $('status').classList.toggle('warning', failed || stale || !s?.permission || s?.diagnostic !== 'ok');
  $('sync-note').textContent=note;
}

function renderSummary() {
  const now = data.server_time;
  $('issue-date').textContent=dateKey(now).replaceAll('-', ' / ');
  $('issue-weekday').textContent=new Intl.DateTimeFormat('zh-CN',{timeZone:zone,weekday:'long'}).format(now)+' · 北京时间';
  const parts = data.last_unlock == null ? ['—','—'] : formatTime(data.last_unlock).split(':');
  const colon=document.createElement('span'); colon.className='colon'; colon.textContent=':';
  $('last-time').replaceChildren(document.createTextNode(parts[0]),colon,document.createTextNode(parts[1]));
  $('last-date').textContent=data.last_unlock == null ? '尚无解锁记录' : dateKey(data.last_unlock).replaceAll('-', ' / ')+' 的一次解锁';
  const s=data.snapshot;
  $('battery').textContent=s?.battery ?? '—';
  $('battery-fill').setAttribute('width', String((s?.battery ?? 0)*.32));
  $('charging').textContent=s?.charging == null ? '充电状态未知' : s.charging ? '上报时正在充电' : '上报时未充电';
  $('received').textContent=stamp(s?.received);
  $('covered').textContent=stamp(s?.covered_until);
  renderStatus();
}

function renderDay() {
  const day=data.daily.find(item=>item.date===selected);
  if (!day) return;
  $('selected-date').textContent=day.date.replaceAll('-',' / ');
  // With no observations at all, zero is not evidence of no phone use.
  const available=Boolean(data.snapshot) && (!day.incomplete || day.unlocks>0 || day.screen_ms>0 || day.unlocked_ms>0);
  $('unlocks').textContent=available ? String(day.unlocks) : '—';
  duration('screen',day.screen_ms,available); duration('unlocked',day.unlocked_ms,available);
  $('coverage-note').textContent=!data.snapshot ? '尚未收到手机数据，完成同步后即可查看。' : day.incomplete ? '此日采集范围不完整，数值仅为已记录部分；缺失不等于没有使用。' : '已查询此日截至采集时间的范围；系统仍可能漏记，时长仅计入完整区间。';
  renderEvents();
}

function renderChart() {
  const days=data.daily.slice(-range);
  const max=Math.max(1,...days.map(d=>d.unlocks));
  const chart=$('chart'); chart.replaceChildren(); chart.classList.toggle('month',range===30);
  const ns='http://www.w3.org/2000/svg';
  days.forEach(day=>{
    const button=document.createElement('button'); button.type='button'; button.className='day-bar'; button.setAttribute('aria-pressed',String(day.date===selected));
    const unknown=day.incomplete && day.unlocks===0;
    const description=`${day.date}，${unknown?'暂无解锁记录':day.unlocks+' 次解锁'}${day.incomplete?'，采集不完整':''}`;
    button.setAttribute('aria-label',description); button.title=description;
    const count=document.createElement('span'); count.className='bar-count'; count.textContent=unknown?'—':String(day.unlocks);
    const svg=document.createElementNS(ns,'svg'); svg.setAttribute('viewBox','0 0 40 118'); svg.setAttribute('preserveAspectRatio','none'); svg.setAttribute('aria-hidden','true'); svg.classList.add('bar-svg');
    const bar=document.createElementNS(ns,'rect'); const height=day.unlocks/max*110; bar.setAttribute('x','5'); bar.setAttribute('width','30'); bar.setAttribute('y',String(118-height)); bar.setAttribute('height',String(height)); bar.classList.add('bar-fill'); svg.append(bar);
    if(day.incomplete){const line=document.createElementNS(ns,'line'); line.setAttribute('x1','0');line.setAttribute('x2','40');line.setAttribute('y1','117');line.setAttribute('y2','117');line.classList.add('bar-base');svg.append(line);}
    const label=document.createElement('span');label.className='bar-label';label.textContent=range===7?day.date.slice(5).replace('-','/'):day.date.slice(8);
    button.append(count,svg,label);
    button.addEventListener('click',()=>{selected=day.date;expanded=false;chart.querySelectorAll('.day-bar').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));renderDay();});
    chart.append(button);
  });
  $('chart-start').textContent=days[0]?.date.slice(5).replace('-','/')??'—';
  $('chart-end').textContent=days.at(-1)?.date.slice(5).replace('-','/')??'—';
}

function renderEvents() {
  const filter=$('event-filter').value;
  const events=data.timeline.filter(e=>dateKey(e.at)===selected && (filter==='all'||e.kind===filter));
  const list=$('events');list.replaceChildren();
  if (!events.length) { const empty=document.createElement('li');empty.className='empty';empty.textContent='此日期暂无符合条件的事件。较早事件可能已超出最近 100 条范围。';list.append(empty); }
  (expanded?events:events.slice(0,6)).forEach(e=>{
    const names=kinds[e.kind]||['其他事件','EVENT']; const li=document.createElement('li');li.className='event-row '+(kinds[e.kind]?e.kind:'');
    const time=document.createElement('time');time.className='event-time';time.dateTime=new Date(e.at).toISOString();time.textContent=formatTime(e.at,true);
    const name=document.createElement('span');name.className='event-kind';const dot=document.createElement('span');dot.className='event-dot';dot.setAttribute('aria-hidden','true');name.append(dot,document.createTextNode(names[0]));
    const tag=document.createElement('span');tag.className='event-tag';tag.textContent=names[1];li.append(time,name,tag);list.append(li);
  });
  $('more-events').hidden=events.length<=6;
  $('more-events').textContent=expanded?'收起记录 ↑':`展开其余 ${events.length-6} 条记录 ↓`;
}

async function refresh() {
  if(inFlight)return;
  inFlight=true;$('refresh').disabled=true;$('refresh').textContent='正在刷新…';
  try {
    const response=await fetch('/api/v1/dashboard',{cache:'no-store',signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw new Error('HTTP '+response.status);
    const next=await response.json();
    if(!Array.isArray(next.daily)||!next.daily.length||!Array.isArray(next.timeline)||!Number.isFinite(next.server_time))throw new Error('Invalid response');
    const wasToday=!data || selected===data.daily.at(-1).date;
    data=next; fetchedAt=Date.now(); failed=false;
    if(wasToday || !data.daily.some(d=>d.date===selected))selected=data.daily.at(-1).date;
    $('load-error').hidden=true;renderSummary();renderDay();renderChart();
  } catch(error) {
    failed=true;$('load-error').hidden=false;$('load-error').textContent=data?'刷新失败，以下为上次读取的记录。请稍后点击“刷新记录”重试。':'暂时无法读取手机记录，请检查连接后点击“刷新记录”重试。';
    if(data)renderStatus();else { $('status').textContent='读取失败';$('status').classList.add('warning');$('sync-note').textContent='连接恢复后可重新读取。';$('coverage-note').textContent='数据暂不可用。';$('events').firstElementChild.textContent='暂时无法读取事件。'; }
  } finally {inFlight=false;$('refresh').disabled=false;$('refresh').textContent='刷新记录 ↻';}
}

$('refresh').addEventListener('click',refresh);
$('event-filter').addEventListener('change',()=>{expanded=false;if(data)renderEvents();});
$('more-events').addEventListener('click',()=>{expanded=!expanded;renderEvents();});
document.querySelectorAll('[data-range]').forEach(button=>button.addEventListener('click',()=>{
  range=Number(button.dataset.range);
  document.querySelectorAll('[data-range]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  if(data){if(!data.daily.slice(-range).some(d=>d.date===selected)){selected=data.daily.at(-1).date;expanded=false;renderDay();}renderChart();}
}));
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
setInterval(()=>{if(!document.hidden)refresh();},60000);
setInterval(renderStatus,15000);
refresh();
